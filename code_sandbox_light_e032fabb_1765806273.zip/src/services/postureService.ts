import { PostureAnalysis } from '../types/posture'

const API_BASE_URL = '/api'

class PostureService {
  // Save a new posture scan
  async saveScan(analysis: Omit<PostureAnalysis, 'id'>) {
    try {
      const response = await fetch(`${API_BASE_URL}/posture_scans`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          score: analysis.score,
          issues: analysis.issues,
          exercises: analysis.exercises,
          notes: analysis.notes || '',
          timestamp: analysis.timestamp,
          user_id: analysis.user_id || null
        })
      })

      if (!response.ok) {
        throw new Error('Failed to save scan')
      }

      return await response.json()
    } catch (error) {
      console.error('Error saving scan:', error)
      // Fallback to localStorage
      return this.saveScanToLocal(analysis)
    }
  }

  // Get all scans for a user
  async getUserScans(userId?: string) {
    try {
      const url = userId 
        ? `${API_BASE_URL}/posture_scans?user_id=${userId}&sort=timestamp&order=desc`
        : `${API_BASE_URL}/posture_scans?sort=timestamp&order=desc`
      
      const response = await fetch(url)
      
      if (!response.ok) {
        throw new Error('Failed to fetch scans')
      }

      const data = await response.json()
      return data.data
    } catch (error) {
      console.error('Error fetching scans:', error)
      // Fallback to localStorage
      return this.getScansFromLocal()
    }
  }

  // Get a single scan
  async getScan(id: string) {
    try {
      const response = await fetch(`${API_BASE_URL}/posture_scans/${id}`)
      
      if (!response.ok) {
        throw new Error('Failed to fetch scan')
      }

      return await response.json()
    } catch (error) {
      console.error('Error fetching scan:', error)
      // Fallback to localStorage
      return this.getScanFromLocal(id)
    }
  }

  // Delete a scan
  async deleteScan(id: string) {
    try {
      const response = await fetch(`${API_BASE_URL}/posture_scans/${id}`, {
        method: 'DELETE'
      })
      
      if (!response.ok) {
        throw new Error('Failed to delete scan')
      }

      return true
    } catch (error) {
      console.error('Error deleting scan:', error)
      // Fallback to localStorage
      return this.deleteScanFromLocal(id)
    }
  }

  // Local storage fallback methods
  private saveScanToLocal(analysis: Omit<PostureAnalysis, 'id'>) {
    const scans = this.getScansFromLocal()
    const newScan = {
      id: Date.now().toString(),
      ...analysis,
      gs_project_id: 'local',
      gs_table_name: 'posture_scans',
      created_at: Date.now(),
      updated_at: Date.now()
    }
    
    scans.unshift(newScan)
    localStorage.setItem('posture_scans', JSON.stringify(scans))
    
    return newScan
  }

  private getScansFromLocal() {
    try {
      const scans = localStorage.getItem('posture_scans')
      return scans ? JSON.parse(scans) : []
    } catch (error) {
      console.error('Error reading from localStorage:', error)
      return []
    }
  }

  private getScanFromLocal(id: string) {
    const scans = this.getScansFromLocal()
    return scans.find((scan: any) => scan.id === id) || null
  }

  private deleteScanFromLocal(id: string) {
    const scans = this.getScansFromLocal()
    const filteredScans = scans.filter((scan: any) => scan.id !== id)
    localStorage.setItem('posture_scans', JSON.stringify(filteredScans))
    return true
  }

  // Analytics methods
  async getProgressData(userId?: string) {
    const scans = await this.getUserScans(userId)
    
    // Group by date and calculate average scores
    const dailyScores = scans.reduce((acc: any, scan: any) => {
      const date = new Date(scan.timestamp).toISOString().split('T')[0]
      if (!acc[date]) {
        acc[date] = { total: 0, count: 0 }
      }
      acc[date].total += scan.score
      acc[date].count += 1
      return acc
    }, {})

    const progressData = Object.entries(dailyScores).map(([date, data]: [string, any]) => ({
      date,
      score: Math.round(data.total / data.count)
    }))

    return progressData.sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
  }

  async getMostCommonIssues(userId?: string) {
    const scans = await this.getUserScans(userId)
    
    const issueCounts = scans.reduce((acc: any, scan: any) => {
      scan.issues.forEach((issue: string) => {
        acc[issue] = (acc[issue] || 0) + 1
      })
      return acc
    }, {})

    return Object.entries(issueCounts)
      .sort(([, a], [, b]) => (b as number) - (a as number))
      .slice(0, 5)
      .map(([issue, count]) => ({ issue, count }))
  }
}

export default new PostureService()