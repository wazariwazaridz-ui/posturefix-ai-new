import React from 'react'
import { BrowserRouter } from 'react-router-dom'
import AppRoutes from './routes'
import { ServiceWorkerProvider } from './contexts/ServiceWorkerContext'
import { PremiumProvider } from './contexts/PremiumContext'

function App() {
  return (
    <ServiceWorkerProvider>
      <PremiumProvider>
        <BrowserRouter>
          <AppRoutes />
        </BrowserRouter>
      </PremiumProvider>
    </ServiceWorkerProvider>
  )
}

export default App