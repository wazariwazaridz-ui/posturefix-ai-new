import React from 'react'
import { Link } from 'react-router-dom'
import { usePremium } from '../contexts/PremiumContext'
import AdBanner from '../components/AdBanner'

const Settings = () => {
  const { isPremium, loading, upgradeToPremium, restorePurchase } = usePremium()

  const handleUpgrade = async () => {
    if (loading) return
    await upgradeToPremium()
  }

  const handleRestore = async () => {
    if (loading) return
    await restorePurchase()
  }
  return (
    <div className="min-h-screen bg-gray-50 p-4 safe-area-top safe-area-bottom">
      <div className="max-w-md mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-xl font-bold text-gray-900">Settings</h1>
          <button className="text-primary-600 hover:text-primary-700 text-sm font-medium">
            Reset
          </button>
        </div>

        {/* Notifications */}
        <div className="bg-white rounded-2xl p-6 mb-6 card">
          <h3 className="font-medium text-gray-900 mb-4">Notifications</h3>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <div className="font-medium text-gray-900">Daily reminders</div>
                <div className="text-sm text-gray-600">Get reminded to check posture</div>
              </div>
              <button className="relative inline-flex h-6 w-11 items-center rounded-full bg-primary-600 transition-colors">
                <span className="inline-block h-4 w-4 transform rounded-full bg-white transition" />
              </button>
            </div>
            <div className="flex items-center justify-between">
              <div>
                <div className="font-medium text-gray-900">Progress updates</div>
                <div className="text-sm text-gray-600">Weekly progress summaries</div>
              </div>
              <button className="relative inline-flex h-6 w-11 items-center rounded-full bg-gray-200 transition-colors">
                <span className="inline-block h-4 w-4 transform translate-x-5 rounded-full bg-white transition" />
              </button>
            </div>
          </div>
        </div>

        {/* Privacy */}
        <div className="bg-white rounded-2xl p-6 mb-6 card">
          <h3 className="font-medium text-gray-900 mb-4">Privacy</h3>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <div className="font-medium text-gray-900">Anonymous analytics</div>
                <div className="text-sm text-gray-600">Help improve the app</div>
              </div>
              <button className="relative inline-flex h-6 w-11 items-center rounded-full bg-gray-200 transition-colors">
                <span className="inline-block h-4 w-4 transform translate-x-5 rounded-full bg-white transition" />
              </button>
            </div>
          </div>
        </div>

        {/* Premium */}
        <div className="bg-gradient-to-r from-primary-600 to-primary-700 rounded-2xl p-6 mb-6 text-white">
          <h3 className="font-medium mb-2">
            {isPremium ? 'PostureFix Premium' : 'Upgrade to Premium'}
          </h3>
          <p className="text-sm opacity-90 mb-4">
            {isPremium 
              ? 'Thank you for supporting PostureFix AI! Your premium features are active.'
              : 'Remove ads and get advanced analytics'
            }
          </p>
          {!isPremium && (
            <div className="space-y-2">
              <button 
                onClick={handleUpgrade}
                disabled={loading}
                className="w-full bg-white text-primary-600 px-4 py-2 rounded-lg text-sm font-medium hover:bg-gray-50 transition-colors disabled:opacity-50"
              >
                {loading ? 'Processing...' : 'Upgrade Now - $9.99'}
              </button>
              <button 
                onClick={handleRestore}
                disabled={loading}
                className="w-full bg-transparent border border-white text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-white hover:bg-opacity-10 transition-colors disabled:opacity-50"
              >
                Restore Purchase
              </button>
            </div>
          )}
        </div>

        {/* About */}
        <div className="bg-white rounded-2xl p-6 card">
          <h3 className="font-medium text-gray-900 mb-4">About</h3>
          <div className="space-y-3 text-sm">
            <div className="flex justify-between">
              <span className="text-gray-600">Version</span>
              <span className="text-gray-900">1.0.0</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">AI Model</span>
              <span className="text-gray-900">MediaPipe Pose</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Privacy</span>
              <span className="text-green-600">On-device processing</span>
            </div>
          </div>
          <div className="mt-4 pt-4 border-t border-gray-200">
            <button className="text-primary-600 hover:text-primary-700 text-sm font-medium">
              Privacy Policy
            </button>
            <br />
            <button className="text-primary-600 hover:text-primary-700 text-sm font-medium">
              Terms of Service
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}

export default Settings