import React, { useState } from 'react'
import Camera from '../components/Camera'
import PoseDetector from '../components/PoseDetector'

const Scan = () => {
  const [scanMode, setScanMode] = useState<'camera' | 'detecting'>('camera')

  const startScan = () => {
    setScanMode('detecting')
  }

  const stopScan = () => {
    setScanMode('camera')
  }

  return (
    <div className="min-h-screen bg-gray-50 p-4 safe-area-top safe-area-bottom">
      <div className="max-w-md mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-xl font-bold text-gray-900">Posture Scan</h1>
          <div className={`w-2 h-2 rounded-full animate-pulse ${
            scanMode === 'detecting' ? 'bg-green-500' : 'bg-gray-400'
          }`}></div>
        </div>

        {/* Camera/Pose Detection */}
        <div className="bg-black rounded-2xl aspect-video mb-6 relative overflow-hidden">
          {scanMode === 'camera' ? (
            <Camera 
              onFrame={() => {}} 
              width={640} 
              height={480}
              facingMode="user"
            />
          ) : (
            <PoseDetector />
          )}
        </div>

        {/* Instructions */}
        <div className="bg-white rounded-2xl p-4 mb-6 card">
          <h3 className="font-medium text-gray-900 mb-3">Position yourself:</h3>
          <ul className="space-y-2 text-sm text-gray-600">
            <li className="flex items-center space-x-2">
              <span className="w-2 h-2 bg-primary-500 rounded-full"></span>
              <span>Stand or sit straight facing the camera</span>
            </li>
            <li className="flex items-center space-x-2">
              <span className="w-2 h-2 bg-primary-500 rounded-full"></span>
              <span>Ensure good lighting on your body</span>
            </li>
            <li className="flex items-center space-x-2">
              <span className="w-2 h-2 bg-primary-500 rounded-full"></span>
              <span>Keep your full body in frame</span>
            </li>
          </ul>
        </div>

        {/* Action Buttons */}
        <div className="space-y-3">
          {scanMode === 'camera' ? (
            <button 
              onClick={startScan}
              className="w-full btn-success text-lg py-4"
            >
              Start AI Scan
            </button>
          ) : (
            <button 
              onClick={stopScan}
              className="w-full btn-warning text-lg py-4"
            >
              Stop Scan
            </button>
          )}
          <button className="w-full btn-outline py-3">
            Back to Home
          </button>
        </div>

        {/* Status */}
        <div className="text-center mt-4">
          <p className="text-xs text-gray-500">
            {scanMode === 'detecting' ? 'Analyzing posture...' : 'Ready to scan'} • Offline capable
          </p>
        </div>
      </div>
    </div>
  )
}

export default Scan