import React from 'react'
import { Link } from 'react-router-dom'
import { usePremium } from '../contexts/PremiumContext'
import AdBanner from '../components/AdBanner'

const Welcome = () => {
  const { isPremium } = usePremium()
  return (
    <div className="min-h-screen bg-gradient-to-br from-primary-50 to-primary-100 flex flex-col justify-center items-center p-4 safe-area-top safe-area-bottom">
      <div className="max-w-md w-full">
        {/* App Icon and Title */}
        <div className="text-center mb-8 animate-fade-in">
          <div className="w-20 h-20 bg-primary-600 rounded-3xl mx-auto mb-4 flex items-center justify-center">
            <svg className="w-10 h-10 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
            </svg>
          </div>
          <h1 className="text-3xl font-bold text-gray-900 mb-2">PostureFix AI</h1>
          <p className="text-gray-600">AI-powered posture correction</p>
        </div>

        {/* Features */}
        <div className="bg-white rounded-2xl p-6 mb-8 card animate-slide-up">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">How it works:</h2>
          <div className="space-y-4">
            <div className="flex items-start space-x-3">
              <div className="w-6 h-6 bg-primary-100 rounded-full flex items-center justify-center flex-shrink-0">
                <span className="text-primary-600 text-sm font-semibold">1</span>
              </div>
              <div>
                <h3 className="font-medium text-gray-900">Position yourself</h3>
                <p className="text-sm text-gray-600">Stand or sit in front of your camera with good lighting</p>
              </div>
            </div>
            <div className="flex items-start space-x-3">
              <div className="w-6 h-6 bg-primary-100 rounded-full flex items-center justify-center flex-shrink-0">
                <span className="text-primary-600 text-sm font-semibold">2</span>
              </div>
              <div>
                <h3 className="font-medium text-gray-900">Get real-time feedback</h3>
                <p className="text-sm text-gray-600">See instant analysis with color-coded visual feedback</p>
              </div>
            </div>
            <div className="flex items-start space-x-3">
              <div className="w-6 h-6 bg-primary-100 rounded-full flex items-center justify-center flex-shrink-0">
                <span className="text-primary-600 text-sm font-semibold">3</span>
              </div>
              <div>
                <h3 className="font-medium text-gray-900">Follow personalized exercises</h3>
                <p className="text-sm text-gray-600">Receive custom exercises to improve your posture</p>
              </div>
            </div>
          </div>
        </div>

        {/* Privacy Notice */}
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-8">
          <div className="flex items-start space-x-2">
            <svg className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
            </svg>
            <div>
              <h4 className="text-sm font-medium text-blue-900">Privacy First</h4>
              <p className="text-xs text-blue-700 mt-1">All processing happens on your device. No images are sent to servers.</p>
            </div>
          </div>
        </div>

        {/* CTA Button */}
        <Link
          to="/scan"
          className="w-full btn-primary text-lg py-4"
        >
          Get Started
        </Link>

        {/* Ad Banner (for non-premium users) */}
        {!isPremium && (
          <div className="mt-6">
            <AdBanner />
          </div>
        )}

        {/* Secondary Actions */}
        <div className="text-center mt-6 space-y-2">
          <Link to="/history" className="text-primary-600 hover:text-primary-700 text-sm font-medium">
            View History
          </Link>
          <br />
          <Link to="/settings" className="text-gray-500 hover:text-gray-700 text-sm">
            Settings
          </Link>
        </div>
      </div>
    </div>
  )
}

export default Welcome