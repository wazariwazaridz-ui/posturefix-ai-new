import React, { useState, useEffect } from 'react'
import { useLocation, Link } from 'react-router-dom'
import { getExercisesByIssues } from '../data/exercises'
import { Exercise } from '../data/exercises'

interface PostureAnalysis {
  score: number
  issues: string[]
  timestamp: number
}

const Results = () => {
  const location = useLocation()
  const [analysis, setAnalysis] = useState<PostureAnalysis | null>(null)
  const [recommendedExercises, setRecommendedExercises] = useState<Exercise[]>([])
  const [selectedExercise, setSelectedExercise] = useState<Exercise | null>(null)

  useEffect(() => {
    // Get analysis results from location state or use mock data
    const analysisData = location.state?.analysis || {
      score: 72,
      issues: ['Forward head posture', 'Uneven shoulders'],
      timestamp: Date.now()
    }
    
    setAnalysis(analysisData)
    
    // Get recommended exercises based on issues
    const exercises = getExercisesByIssues(analysisData.issues)
    setRecommendedExercises(exercises)
  }, [location.state])

  const getScoreColor = (score: number) => {
    if (score >= 80) return 'text-success-600'
    if (score >= 60) return 'text-warning-600'
    return 'text-error-600'
  }

  const getScoreLabel = (score: number) => {
    if (score >= 80) return 'Excellent'
    if (score >= 60) return 'Good'
    if (score >= 40) return 'Fair'
    return 'Needs Improvement'
  }

  const saveToHistory = () => {
    if (!analysis) return
    
    // Save to localStorage (will be replaced with proper database later)
    const history = JSON.parse(localStorage.getItem('postureHistory') || '[]')
    history.push({
      ...analysis,
      id: Date.now().toString()
    })
    localStorage.setItem('postureHistory', JSON.stringify(history))
    
    alert('Scan saved to history!')
  }

  if (!analysis) {
    return (
      <div className="min-h-screen bg-gray-50 p-4 safe-area-top safe-area-bottom flex items-center justify-center">
        <div className="text-center">
          <div className="w-8 h-8 border-2 border-primary-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Loading results...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50 p-4 safe-area-top safe-area-bottom">
      <div className="max-w-md mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-xl font-bold text-gray-900">Scan Results</h1>
          <div className="text-sm text-gray-500">Just now</div>
        </div>

        {/* Score Card */}
        <div className="bg-white rounded-2xl p-6 mb-6 card">
          <div className="text-center">
            <div className={`text-4xl font-bold mb-2 ${getScoreColor(analysis.score)}`}>
              {analysis.score}
            </div>
            <div className="text-sm text-gray-600 mb-2">Posture Score</div>
            <div className={`text-sm font-medium mb-4 ${getScoreColor(analysis.score)}`}>
              {getScoreLabel(analysis.score)}
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2 mb-4">
              <div 
                className={`h-2 rounded-full ${
                  analysis.score >= 80 ? 'bg-success-500' : 
                  analysis.score >= 60 ? 'bg-warning-500' : 'bg-error-500'
                }`} 
                style={{ width: `${analysis.score}%` }}
              ></div>
            </div>
            <p className="text-sm text-gray-600">
              {analysis.score >= 80 ? 'Great job! Keep maintaining good posture.' :
               analysis.score >= 60 ? 'Good foundation with room for improvement.' :
               'Focus on the recommended exercises to improve your posture.'}
            </p>
          </div>
        </div>

        {/* Issues Found */}
        {analysis.issues.length > 0 && (
          <div className="bg-white rounded-2xl p-6 mb-6 card">
            <h3 className="font-medium text-gray-900 mb-4">Issues Detected:</h3>
            <div className="space-y-3">
              {analysis.issues.map((issue, index) => (
                <div key={index} className="flex items-center space-x-3">
                  <div className="w-3 h-3 bg-warning-500 rounded-full"></div>
                  <div>
                    <div className="font-medium text-gray-900">{issue}</div>
                    <div className="text-sm text-gray-600">Detected in current scan</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Recommended Exercises */}
        {recommendedExercises.length > 0 && (
          <div className="bg-white rounded-2xl p-6 mb-6 card">
            <h3 className="font-medium text-gray-900 mb-4">Recommended Exercises:</h3>
            <div className="space-y-3">
              {recommendedExercises.map((exercise) => (
                <div 
                  key={exercise.id}
                  className="flex items-center justify-between p-3 bg-gray-50 rounded-lg cursor-pointer hover:bg-gray-100 transition-colors"
                  onClick={() => setSelectedExercise(exercise)}
                >
                  <div>
                    <div className="font-medium text-gray-900">{exercise.name}</div>
                    <div className="text-sm text-gray-600">{exercise.reps}</div>
                  </div>
                  <button className="text-primary-600 hover:text-primary-700 text-sm font-medium">
                    View
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Exercise Detail Modal */}
        {selectedExercise && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
            <div className="bg-white rounded-2xl max-w-md w-full max-h-[80vh] overflow-y-auto">
              <div className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-semibold text-gray-900">{selectedExercise.name}</h3>
                  <button
                    onClick={() => setSelectedExercise(null)}
                    className="text-gray-400 hover:text-gray-600"
                  >
                    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                    </svg>
                  </button>
                </div>
                
                <p className="text-gray-600 mb-4">{selectedExercise.description}</p>
                
                <div className="mb-4">
                  <h4 className="font-medium text-gray-900 mb-2">Steps:</h4>
                  <ol className="list-decimal list-inside space-y-1 text-sm text-gray-600">
                    {selectedExercise.steps.map((step, index) => (
                      <li key={index}>{step}</li>
                    ))}
                  </ol>
                </div>
                
                <div className="grid grid-cols-2 gap-4 mb-6">
                  <div>
                    <div className="text-sm text-gray-600">Duration</div>
                    <div className="font-medium text-gray-900">{selectedExercise.duration}</div>
                  </div>
                  <div>
                    <div className="text-sm text-gray-600">Reps</div>
                    <div className="font-medium text-gray-900">{selectedExercise.reps}</div>
                  </div>
                </div>
                
                <div className="flex space-x-3">
                  <button 
                    onClick={() => setSelectedExercise(null)}
                    className="flex-1 btn-outline"
                  >
                    Close
                  </button>
                  <button className="flex-1 btn-primary">
                    Start Exercise
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Action Buttons */}
        <div className="space-y-3">
          <button 
            onClick={saveToHistory}
            className="w-full btn-primary text-lg py-4"
          >
            Save to History
          </button>
          <Link to="/scan" className="w-full btn-outline py-3 block text-center">
            Scan Again
          </Link>
          <Link to="/" className="w-full btn-outline py-3 block text-center">
            Back to Home
          </Link>
        </div>
      </div>
    </div>
  )
}

export default Results