import React, { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { Line } from 'react-chartjs-2'
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  ChartOptions
} from 'chart.js'
import postureService from '../services/postureService'
import { PostureAnalysis } from '../types/posture'

// Register Chart.js components
ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
)

const History = () => {
  const [scans, setScans] = useState<PostureAnalysis[]>([])
  const [progressData, setProgressData] = useState<any[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    loadHistory()
  }, [])

  const loadHistory = async () => {
    try {
      setLoading(true)
      const [userScans, progress] = await Promise.all([
        postureService.getUserScans(),
        postureService.getProgressData()
      ])
      
      setScans(userScans)
      setProgressData(progress)
    } catch (error) {
      console.error('Error loading history:', error)
    } finally {
      setLoading(false)
    }
  }

  const clearHistory = async () => {
    if (confirm('Are you sure you want to clear all history? This cannot be undone.')) {
      try {
        // Delete all scans
        await Promise.all(scans.map(scan => postureService.deleteScan(scan.id)))
        setScans([])
        setProgressData([])
      } catch (error) {
        console.error('Error clearing history:', error)
      }
    }
  }

  const deleteScan = async (id: string) => {
    if (confirm('Delete this scan?')) {
      try {
        await postureService.deleteScan(id)
        setScans(scans.filter(scan => scan.id !== id))
      } catch (error) {
        console.error('Error deleting scan:', error)
      }
    }
  }

  const getScoreColor = (score: number) => {
    if (score >= 80) return 'text-success-600'
    if (score >= 60) return 'text-warning-600'
    return 'text-error-600'
  }

  const getScoreLabel = (score: number) => {
    if (score >= 80) return 'Excellent'
    if (score >= 60) return 'Good'
    if (score >= 40) return 'Fair'
    return 'Needs Improvement'
  }

  const formatDate = (timestamp: number) => {
    const date = new Date(timestamp)
    const now = new Date()
    const diffTime = Math.abs(now.getTime() - date.getTime())
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24))
    
    if (diffDays === 0) return 'Today'
    if (diffDays === 1) return 'Yesterday'
    if (diffDays < 7) return `${diffDays} days ago`
    
    return date.toLocaleDateString()
  }

  const formatTime = (timestamp: number) => {
    return new Date(timestamp).toLocaleTimeString([], { 
      hour: '2-digit', 
      minute: '2-digit' 
    })
  }

  // Chart data
  const chartData = {
    labels: progressData.map(d => new Date(d.date).toLocaleDateString()),
    datasets: [
      {
        label: 'Posture Score',
        data: progressData.map(d => d.score),
        borderColor: '#3B82F6',
        backgroundColor: 'rgba(59, 130, 246, 0.1)',
        tension: 0.4,
        fill: true
      }
    ]
  }

  const chartOptions: ChartOptions<'line'> = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        display: false
      },
      tooltip: {
        backgroundColor: 'rgba(0, 0, 0, 0.8)',
        titleColor: 'white',
        bodyColor: 'white',
        borderColor: '#3B82F6',
        borderWidth: 1
      }
    },
    scales: {
      y: {
        beginAtZero: false,
        min: 0,
        max: 100,
        ticks: {
          stepSize: 20
        }
      },
      x: {
        grid: {
          display: false
        }
      }
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 p-4 safe-area-top safe-area-bottom flex items-center justify-center">
        <div className="text-center">
          <div className="w-8 h-8 border-2 border-primary-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Loading history...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50 p-4 safe-area-top safe-area-bottom">
      <div className="max-w-md mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-xl font-bold text-gray-900">History</h1>
          {scans.length > 0 && (
            <button 
              onClick={clearHistory}
              className="text-red-600 hover:text-red-700 text-sm font-medium"
            >
              Clear All
            </button>
          )}
        </div>

        {/* Progress Chart */}
        {progressData.length > 0 && (
          <div className="bg-white rounded-2xl p-6 mb-6 card">
            <h3 className="font-medium text-gray-900 mb-4">Progress Over Time</h3>
            <div className="h-48">
              <Line data={chartData} options={chartOptions} />
            </div>
            <p className="text-xs text-gray-500 mt-2">
              {progressData.length} scans over {progressData.length} days
            </p>
          </div>
        )}

        {/* History List */}
        {scans.length > 0 ? (
          <div className="space-y-4">
            {scans.map((scan) => (
              <div key={scan.id} className="bg-white rounded-2xl p-4 card">
                <div className="flex items-center justify-between mb-2">
                  <div className="text-sm text-gray-500">
                    {formatDate(scan.timestamp)}, {formatTime(scan.timestamp)}
                  </div>
                  <div className="text-lg font-bold ${getScoreColor(scan.score)}">
                    {scan.score}
                  </div>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2 text-sm text-gray-600">
                    {scan.issues.length > 0 ? (
                      <>
                        <span className="w-2 h-2 bg-warning-500 rounded-full"></span>
                        <span>{scan.issues.length} issues</span>
                      </>
                    ) : (
                      <>
                        <span className="w-2 h-2 bg-success-500 rounded-full"></span>
                        <span>Good posture</span>
                      </>
                    )}
                  </div>
                  <button
                    onClick={() => deleteScan(scan.id)}
                    className="text-red-600 hover:text-red-700 text-sm"
                  >
                    Delete
                  </button>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-12">
            <div className="w-16 h-16 bg-gray-100 rounded-full mx-auto mb-4 flex items-center justify-center">
              <svg className="w-8 h-8 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
              </svg>
            </div>
            <h3 className="text-lg font-medium text-gray-900 mb-2">No history yet</h3>
            <p className="text-gray-600 mb-6">Start scanning to track your posture improvement over time</p>
            <Link to="/scan" className="btn-primary">
              Start Scanning
            </Link>
          </div>
        )}
      </div>
    </div>
  )
}

export default History