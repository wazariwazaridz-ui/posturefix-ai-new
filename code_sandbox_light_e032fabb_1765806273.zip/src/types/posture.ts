export interface PostureAnalysis {
  id: string
  score: number
  issues: string[]
  exercises: string[]
  notes?: string
  timestamp: number
  user_id?: string
  created_at?: number
  updated_at?: number
}

export interface User {
  id: string
  email: string
  name: string
  is_premium: boolean
  premium_expires_at?: number
  preferences?: Record<string, any>
  created_at: number
}

export interface ExerciseRecommendation {
  exercise_id: string
  reason: string
  priority: 'high' | 'medium' | 'low'
}

export interface ProgressData {
  date: string
  score: number
}

export interface IssueFrequency {
  issue: string
  count: number
}