import React, { useRef, useEffect, useState } from 'react'
import Camera from '../Camera'

// MediaPipe Pose imports will be loaded dynamically
interface PoseLandmark {
  x: number
  y: number
  z: number
  visibility?: number
}

interface PoseResults {
  poseLandmarks?: PoseLandmark[]
  segmentationMask?: any
  image?: HTMLCanvasElement
}

const PoseDetector: React.FC = () => {
  const [isDetecting, setIsDetecting] = useState(false)
  const [poseResults, setPoseResults] = useState<PoseResults | null>(null)
  const [error, setError] = useState<string | null>(null)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const poseRef = useRef<any>(null)

  useEffect(() => {
    const loadPoseDetector = async () => {
      try {
        // Dynamically import MediaPipe Pose
        const { Pose } = await import('@mediapipe/pose')
        const { Camera: MediaPipeCamera } = await import('@mediapipe/camera_utils')
        const { drawConnectors, drawLandmarks } = await import('@mediapipe/drawing_utils')

        const pose = new Pose({
          locateFile: (file) => {
            return `https://cdn.jsdelivr.net/npm/@mediapipe/pose@0.5.1675469404/${file}`
          }
        })

        pose.setOptions({
          modelComplexity: 1,
          smoothLandmarks: true,
          enableSegmentation: false,
          smoothSegmentation: false,
          minDetectionConfidence: 0.5,
          minTrackingConfidence: 0.5
        })

        pose.onResults((results: PoseResults) => {
          setPoseResults(results)
          drawResults(results)
        })

        poseRef.current = pose
        setIsDetecting(true)
      } catch (err) {
        console.error('Error loading pose detector:', err)
        setError('Failed to load AI pose detector')
      }
    }

    loadPoseDetector()
  }, [])

  const drawResults = (results: PoseResults) => {
    if (!canvasRef.current) return

    const canvas = canvasRef.current
    const ctx = canvas.getContext('2d')
    if (!ctx) return

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height)

    // Draw the results
    if (results.poseLandmarks) {
      drawConnectors(ctx, results.poseLandmarks, 'POSE_CONNECTIONS', { color: '#00FF00', lineWidth: 2 })
      drawLandmarks(ctx, results.poseLandmarks, { color: '#FF0000', lineWidth: 1 })
    }
  }

  const onFrame = (video: HTMLVideoElement, canvas: HTMLCanvasElement) => {
    if (!poseRef.current || !isDetecting) return

    // Send the video frame to pose detector
    poseRef.current.send({ image: video })
  }

  const analyzePosture = (landmarks: PoseLandmark[]): { score: number; issues: string[] } => {
    if (!landmarks || landmarks.length === 0) {
      return { score: 0, issues: [] }
    }

    const issues: string[] = []
    let score = 100

    // Analyze head position
    const nose = landmarks[0]
    const leftEar = landmarks[7]
    const rightEar = landmarks[8]
    
    if (nose && leftEar && rightEar) {
      const headTilt = Math.abs(leftEar.y - rightEar.y)
      if (headTilt > 0.05) {
        issues.push('Head tilt detected')
        score -= 10
      }

      // Forward head posture
      const avgEarY = (leftEar.y + rightEar.y) / 2
      if (nose.y < avgEarY - 0.1) {
        issues.push('Forward head posture')
        score -= 15
      }
    }

    // Analyze shoulder alignment
    const leftShoulder = landmarks[11]
    const rightShoulder = landmarks[12]
    
    if (leftShoulder && rightShoulder) {
      const shoulderHeightDiff = Math.abs(leftShoulder.y - rightShoulder.y)
      if (shoulderHeightDiff > 0.08) {
        issues.push('Uneven shoulders')
        score -= 15
      }
    }

    // Analyze hip alignment
    const leftHip = landmarks[23]
    const rightHip = landmarks[24]
    
    if (leftHip && rightHip) {
      const hipHeightDiff = Math.abs(leftHip.y - rightHip.y)
      if (hipHeightDiff > 0.08) {
        issues.push('Uneven hips')
        score -= 10
      }
    }

    return { score: Math.max(0, score), issues }
  }

  const postureAnalysis = poseResults?.poseLandmarks ? analyzePosture(poseResults.poseLandmarks) : null

  return (
    <div className="relative">
      <Camera onFrame={onFrame} />
      
      {/* Overlay Canvas */}
      <canvas
        ref={canvasRef}
        width={640}
        height={480}
        className="absolute top-0 left-0 w-full h-full pointer-events-none"
      />

      {/* Posture Score Overlay */}
      {postureAnalysis && (
        <div className="absolute top-4 left-4 bg-black bg-opacity-70 text-white px-3 py-2 rounded-lg">
          <div className="text-sm font-medium">Posture Score</div>
          <div className="text-2xl font-bold">
            {postureAnalysis.score}/100
          </div>
          {postureAnalysis.issues.length > 0 && (
            <div className="text-xs mt-1 text-yellow-300">
              {postureAnalysis.issues.length} issues detected
            </div>
          )}
        </div>
      )}

      {/* Status Indicator */}
      <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2">
        <div className={`px-3 py-1 rounded-full text-xs font-medium ${
          isDetecting ? 'bg-green-500 text-white' : 'bg-gray-500 text-white'
        }`}>
          {isDetecting ? 'AI Active' : 'AI Loading...'}
        </div>
      </div>

      {error && (
        <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center">
          <div className="bg-white p-4 rounded-lg text-center">
            <p className="text-red-600 font-medium">{error}</p>
          </div>
        </div>
      )}
    </div>
  )
}

export default PoseDetector