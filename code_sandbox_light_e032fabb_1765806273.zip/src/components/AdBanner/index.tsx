import React from 'react'

interface AdBannerProps {
  placement?: 'top' | 'bottom' | 'inline'
  className?: string
}

const AdBanner: React.FC<AdBannerProps> = ({ 
  placement = 'inline', 
  className = '' 
}) => {
  const [showAd, setShowAd] = React.useState(true)

  const handleAdClick = () => {
    // Simulate ad click
    console.log('Ad clicked')
    // In a real app, this would track ad revenue
  }

  const hideAd = () => {
    setShowAd(false)
    // In a real app, this would be limited or require premium
  }

  if (!showAd) return null

  return (
    <div className={`relative bg-gray-100 border border-gray-200 rounded-lg p-4 text-center ${className}`}>
      {/* Ad Content */}
      <div 
        className="cursor-pointer hover:bg-gray-50 transition-colors"
        onClick={handleAdClick}
      >
        <div className="flex items-center justify-center space-x-3 mb-2">
          <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center">
            <span className="text-white text-xs font-bold">Ad</span>
          </div>
          <div className="text-left">
            <div className="text-sm font-medium text-gray-900">Upgrade to Premium</div>
            <div className="text-xs text-gray-600">Remove ads and unlock advanced features</div>
          </div>
        </div>
        <button className="btn-primary text-sm px-4 py-2">
          Learn More
        </button>
      </div>

      {/* Close Button */}
      <button
        onClick={hideAd}
        className="absolute top-2 right-2 text-gray-400 hover:text-gray-600"
        title="Hide ad"
      >
        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
        </svg>
      </button>

      {/* Ad Label */}
      <div className="absolute bottom-1 right-2 text-xs text-gray-400">
        Advertisement
      </div>
    </div>
  )
}

export default AdBanner