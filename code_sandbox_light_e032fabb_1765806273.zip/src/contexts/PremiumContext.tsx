import React, { createContext, useContext, useState, useEffect } from 'react'

interface PremiumContextType {
  isPremium: boolean
  loading: boolean
  upgradeToPremium: () => Promise<void>
  restorePurchase: () => Promise<void>
}

const PremiumContext = createContext<PremiumContextType | undefined>(undefined)

export const PremiumProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [isPremium, setIsPremium] = useState(false)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    checkPremiumStatus()
  }, [])

  const checkPremiumStatus = () => {
    // Check localStorage for premium status (in real app, this would check with app store)
    const premiumStatus = localStorage.getItem('posturefix_premium')
    const expiryDate = localStorage.getItem('posturefix_premium_expires')
    
    if (premiumStatus === 'true' && expiryDate) {
      const expiry = new Date(expiryDate)
      const now = new Date()
      
      if (expiry > now) {
        setIsPremium(true)
      } else {
        // Premium expired
        localStorage.removeItem('posturefix_premium')
        localStorage.removeItem('posturefix_premium_expires')
        setIsPremium(false)
      }
    }
    
    setLoading(false)
  }

  const upgradeToPremium = async () => {
    setLoading(true)
    
    try {
      // Simulate purchase process
      await new Promise(resolve => setTimeout(resolve, 2000))
      
      // Set premium status (in real app, this would be handled by app store)
      const expiryDate = new Date()
      expiryDate.setFullYear(expiryDate.getFullYear() + 1) // 1 year premium
      
      localStorage.setItem('posturefix_premium', 'true')
      localStorage.setItem('posturefix_premium_expires', expiryDate.toISOString())
      
      setIsPremium(true)
      
      // Show success message
      alert('Successfully upgraded to Premium! 🎉\n\nPremium features unlocked:\n• No ads\n• Advanced analytics\n• Unlimited scans\n• Priority support')
      
    } catch (error) {
      console.error('Premium upgrade failed:', error)
      alert('Premium upgrade failed. Please try again.')
    } finally {
      setLoading(false)
    }
  }

  const restorePurchase = async () => {
    setLoading(true)
    
    try {
      // Simulate purchase restoration
      await new Promise(resolve => setTimeout(resolve, 1500))
      
      // Check if there's a purchase to restore (in real app, this would check app store)
      const hasPurchase = localStorage.getItem('posturefix_premium')
      
      if (hasPurchase === 'true') {
        checkPremiumStatus()
        alert('Purchase restored successfully!')
      } else {
        alert('No previous purchase found to restore.')
      }
      
    } catch (error) {
      console.error('Purchase restoration failed:', error)
      alert('Failed to restore purchase. Please try again.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <PremiumContext.Provider value={{
      isPremium,
      loading,
      upgradeToPremium,
      restorePurchase
    }}>
      {children}
    </PremiumContext.Provider>
  )
}

export const usePremium = () => {
  const context = useContext(PremiumContext)
  if (context === undefined) {
    throw new Error('usePremium must be used within a PremiumProvider')
  }
  return context
}