import React, { createContext, useContext, useEffect, useState } from 'react'
import { Workbox } from 'workbox-window'

interface ServiceWorkerContextType {
  wb: Workbox | null
  needRefresh: boolean
  offlineReady: boolean
  updateServiceWorker: () => void
}

const ServiceWorkerContext = createContext<ServiceWorkerContextType | undefined>(undefined)

export const ServiceWorkerProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [wb, setWb] = useState<Workbox | null>(null)
  const [needRefresh, setNeedRefresh] = useState(false)
  const [offlineReady, setOfflineReady] = useState(false)

  useEffect(() => {
    if ('serviceWorker' in navigator) {
      const workbox = new Workbox('/sw.js')
      
      workbox.addEventListener('installed', (event) => {
        if (event.isUpdate) {
          setNeedRefresh(true)
        } else {
          setOfflineReady(true)
        }
      })

      workbox.addEventListener('waiting', () => {
        setNeedRefresh(true)
      })

      workbox.register()
      setWb(workbox)
    }
  }, [])

  const updateServiceWorker = () => {
    if (wb) {
      wb.messageSkipWaiting()
      setNeedRefresh(false)
      window.location.reload()
    }
  }

  return (
    <ServiceWorkerContext.Provider value={{
      wb,
      needRefresh,
      offlineReady,
      updateServiceWorker
    }}>
      {children}
    </ServiceWorkerContext.Provider>
  )
}

export const useServiceWorker = () => {
  const context = useContext(ServiceWorkerContext)
  if (context === undefined) {
    throw new Error('useServiceWorker must be used within a ServiceWorkerProvider')
  }
  return context
}