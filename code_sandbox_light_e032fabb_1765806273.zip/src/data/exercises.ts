export interface Exercise {
  id: string
  name: string
  description: string
  steps: string[]
  duration: string
  reps: string
  difficulty: 'beginner' | 'intermediate' | 'advanced'
  targetAreas: string[]
  gifUrl?: string
  videoUrl?: string
}

export const exercises: Exercise[] = [
  {
    id: 'chin-tucks',
    name: 'Chin Tucks',
    description: 'Strengthen neck muscles and correct forward head posture',
    steps: [
      'Sit or stand with your back straight',
      'Gently tuck your chin in towards your neck',
      'Hold for 5 seconds',
      'Release and repeat'
    ],
    duration: '2-3 minutes',
    reps: '10 reps • 2 sets daily',
    difficulty: 'beginner',
    targetAreas: ['neck', 'upper-back']
  },
  {
    id: 'shoulder-blade-squeeze',
    name: 'Shoulder Blade Squeeze',
    description: 'Improve shoulder alignment and upper back posture',
    steps: [
      'Sit or stand with arms at your sides',
      'Squeeze shoulder blades together',
      'Hold for 5 seconds',
      'Release slowly'
    ],
    duration: '3-4 minutes',
    reps: '12 reps • 2 sets daily',
    difficulty: 'beginner',
    targetAreas: ['shoulders', 'upper-back']
  },
  {
    id: 'wall-angles',
    name: 'Wall Angels',
    description: 'Correct rounded shoulders and improve posture',
    steps: [
      'Stand with back against wall',
      'Arms at 90 degrees against wall',
      'Slide arms up and down slowly',
      'Keep contact with wall throughout'
    ],
    duration: '4-5 minutes',
    reps: '8 reps • 2 sets daily',
    difficulty: 'intermediate',
    targetAreas: ['shoulders', 'upper-back', 'chest']
  },
  {
    id: 'neck-stretches',
    name: 'Neck Stretches',
    description: 'Relieve neck tension and improve flexibility',
    steps: [
      'Sit or stand with straight spine',
      'Tilt head to right, hold 15 seconds',
      'Tilt head to left, hold 15 seconds',
      'Repeat 2-3 times each side'
    ],
    duration: '3-4 minutes',
    reps: '5 reps • 2 sets daily',
    difficulty: 'beginner',
    targetAreas: ['neck', 'shoulders']
  },
  {
    id: 'hip-flexor-stretch',
    name: 'Hip Flexor Stretch',
    description: 'Correct anterior pelvic tilt and lower back posture',
    steps: [
      'Kneel on one knee',
      'Push hips forward gently',
      'Feel stretch in front of hip',
      'Hold 30 seconds each side'
    ],
    duration: '5-6 minutes',
    reps: '3 reps each side • 2 sets daily',
    difficulty: 'intermediate',
    targetAreas: ['hips', 'lower-back']
  },
  {
    id: 'cat-cow-stretch',
    name: 'Cat-Cow Stretch',
    description: 'Improve spine mobility and posture awareness',
    steps: [
      'Start on hands and knees',
      'Arch back up like cat',
      'Drop belly down like cow',
      'Move slowly between positions'
    ],
    duration: '4-5 minutes',
    reps: '10 reps • 2 sets daily',
    difficulty: 'beginner',
    targetAreas: ['spine', 'lower-back', 'neck']
  },
  {
    id: 'plank',
    name: 'Plank',
    description: 'Strengthen core muscles for better posture',
    steps: [
      'Start in push-up position',
      'Lower to forearms',
      'Keep body straight',
      'Hold position steadily'
    ],
    duration: '2-3 minutes',
    reps: '30-60 seconds • 3 sets',
    difficulty: 'intermediate',
    targetAreas: ['core', 'shoulders']
  },
  {
    id: 'thoracic-extension',
    name: 'Thoracic Extension',
    description: 'Improve upper back mobility and reduce hunching',
    steps: [
      'Sit on chair with back straight',
      'Place hands behind head',
      'Arch upper back gently',
      'Return to neutral position'
    ],
    duration: '3-4 minutes',
    reps: '12 reps • 2 sets daily',
    difficulty: 'intermediate',
    targetAreas: ['upper-back', 'thoracic-spine']
  },
  {
    id: 'pectoralis-stretch',
    name: 'Pectoralis Stretch',
    description: 'Open up chest muscles and correct rounded shoulders',
    steps: [
      'Stand facing corner',
      'Forearms on walls at 90 degrees',
      'Lean forward gently',
      'Feel stretch across chest'
    ],
    duration: '4-5 minutes',
    reps: '30 seconds • 3 sets',
    difficulty: 'beginner',
    targetAreas: ['chest', 'shoulders']
  },
  {
    id: 'bridges',
    name: 'Glute Bridges',
    description: 'Strengthen glutes and lower back for better posture',
    steps: [
      'Lie on back with knees bent',
      'Lift hips up slowly',
      'Squeeze glutes at top',
      'Lower down with control'
    ],
    duration: '4-5 minutes',
    reps: '15 reps • 3 sets',
    difficulty: 'intermediate',
    targetAreas: ['glutes', 'lower-back']
  },
  {
    id: 'bird-dog',
    name: 'Bird Dog',
    description: 'Improve balance and core stability for posture',
    steps: [
      'Start on hands and knees',
      'Extend right arm forward',
      'Extend left leg back',
      'Hold steady, then switch sides'
    ],
    duration: '5-6 minutes',
    reps: '10 each side • 2 sets',
    difficulty: 'advanced',
    targetAreas: ['core', 'balance', 'stability']
  },
  {
    id: 'side-plank',
    name: 'Side Plank',
    description: 'Strengthen obliques for lateral stability',
    steps: [
      'Lie on side, elbow under shoulder',
      'Lift hips up straight',
      'Keep body in line',
      'Hold position steadily'
    ],
    duration: '3-4 minutes',
    reps: '20-30 seconds each side • 2 sets',
    difficulty: 'advanced',
    targetAreas: ['obliques', 'core', 'shoulders']
  },
  {
    id: 'seated-spinal-twist',
    name: 'Seated Spinal Twist',
    description: 'Improve spinal mobility and reduce stiffness',
    steps: [
      'Sit with legs extended',
      'Cross one leg over other',
      'Twist gently towards bent knee',
      'Hold and breathe deeply'
    ],
    duration: '4-5 minutes',
    reps: '30 seconds each side • 2 sets',
    difficulty: 'intermediate',
    targetAreas: ['spine', 'lower-back', 'obliques']
  }
]

export const getExercisesByIssues = (issues: string[]): Exercise[] => {
  const exerciseMap: Record<string, string[]> = {
    'Forward head posture': ['chin-tucks', 'neck-stretches'],
    'Head tilt detected': ['neck-stretches', 'seated-spinal-twist'],
    'Uneven shoulders': ['shoulder-blade-squeeze', 'side-plank'],
    'Uneven hips': ['hip-flexor-stretch', 'bridges'],
    'Rounded shoulders': ['wall-angles', 'pectoralis-stretch'],
    'Thoracic stiffness': ['thoracic-extension', 'cat-cow-stretch']
  }

  const recommendedExerciseIds = new Set<string>()
  
  issues.forEach(issue => {
    const exerciseIds = exerciseMap[issue] || []
    exerciseIds.forEach(id => recommendedExerciseIds.add(id))
  })

  // If no specific issues, return general posture exercises
  if (recommendedExerciseIds.size === 0) {
    return exercises.filter(ex => 
      ['chin-tucks', 'shoulder-blade-squeeze', 'neck-stretches'].includes(ex.id)
    )
  }

  return exercises.filter(ex => recommendedExerciseIds.has(ex.id))
}

export const getExercisesByDifficulty = (difficulty: 'beginner' | 'intermediate' | 'advanced'): Exercise[] => {
  return exercises.filter(ex => ex.difficulty === difficulty)
}

export const getExerciseById = (id: string): Exercise | undefined => {
  return exercises.find(ex => ex.id === id)
}